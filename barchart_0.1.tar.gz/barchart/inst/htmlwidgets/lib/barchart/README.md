# barchart
Interactive bar chart with d3.js

![alt text](https://raw.githubusercontent.com/alexrfling/barchart/master/img/example.png)
